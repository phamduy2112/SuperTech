import { v2 as cloudinary } from 'cloudinary';

cloudinary.config({ 
  cloud_name: 'dcvkmhlhw', 
  api_key: '658277699652542', 
  api_secret: 'GtIqfhfgtN0ERCSj9QUQpnG-5b4' 
});

export default cloudinary;