const colorText = [
    { status: 0, color: "#FF0000", text: "Đang chờ duyệt" }, // Đỏ
    { status: 1, color: "#FFA500", text: "Đang chuẩn bị hàng" }, // Cam
    { status: 2, color: "#00FFFF", text: "Đã chuẩn bị hàng" }, // Xanh ngọc (cập nhật)
    { status: 3, color: "#008000", text: "Đang giao hàng" }, // Xanh lá
    { status: 4, color: "#800080", text: "Thành công" }, // Tím
    { status: 5, color: "#999999", text: "Không nhận hàng" }, // Xám
    { status: 6, color: "#FF69B4", text: "Hủy hàng" }, // Hồng (cập nhật)
  ];