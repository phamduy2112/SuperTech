import S from './Loading.module.css';

function LoadPage() {
  return (
    <div className={`${S['spinner-1']}`}></div>
  )
}

export default LoadPage
