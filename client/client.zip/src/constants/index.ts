// export const URL_BACKEND="https://dichvumang86.cloud/"
export const URL_BACKEND="http://localhost:8080/"
export const IMG_BACKEND="https://res.cloudinary.com/dcvkmhlhw/image/upload/v1730647279/"
export const IMG_BACKEND_USER="https://res.cloudinary.com/dcvkmhlhw/image/upload/v1732655979/User"

export const colorText = [
    { status: 0, color: "#D32F2F", text: "Đang chờ duyệt" }, // Đỏ đậm
    { status: 1, color: "#FF9800", text: "Đang chuẩn bị hàng" }, // Cam sáng
    { status: 2, color: "#0288D1", text: "Đã chuẩn bị hàng" }, // Xanh dương đậm
    { status: 3, color: "#388E3C", text: "Đang giao hàng" }, // Xanh lá đậm
    { status: 4, color: "#7B1FA2", text: "Thành công" }, // Tím đậm
    { status: 5, color: "#616161", text: "Không nhận hàng" }, // Xám đậm
    { status: 6, color: "#212121", text: "Hủy hàng" }, // Đen nhạt
  ];