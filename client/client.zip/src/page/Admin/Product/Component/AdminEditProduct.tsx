import { GetProp, Select, Upload, UploadFile } from 'antd';
import React, { useEffect, useState } from 'react';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css'
import ImgCrop from 'antd-img-crop';
import { UploadProps } from 'antd/lib';
import { useNavigate, useParams } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { useAppSelector } from '../../../../redux/hooks';
import { getProductByIdThunk, putInforProductAdminThunk } from '../../../../redux/product/product.slice';
import { Formik, Field, Form, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import ModalAdminProduct from './ModalAdminProduct';
import { getCatelogryThunk } from '../../../../redux/catelogry/catelogry.slice';
import toast from 'react-hot-toast';
type FileType = Parameters<GetProp<UploadProps, 'beforeUpload'>>[0];


function AdminEditProduct(props) {
  const [showForm, setShowForm] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState(null);

  const { id } = useParams();
  const numericId = Number(id); // Ép chuỗi id thành số
const dispatch=useDispatch()
const productDetail=useAppSelector((state)=>state.product.productDetail)
console.log(productDetail);
const listCatelogry=useAppSelector((state)=>state.category.listCatelories)

const formattedCategories = listCatelogry?.map(category => ({
  value: category.category_id,   // Make sure category.id is available
  label: category.category_name, // Make sure category.name is available
  category_dad:category.category_dad
}));
useEffect(()=>{
  if (!isNaN(numericId)) {
    dispatch(getProductByIdThunk(numericId));

  }
  dispatch(getCatelogryThunk(""));

},[numericId,dispatch])
 


  const Datahe = [
    {
      value: '1',
      label: 'HDD Level 1',
    },
    {
      value: '2',
      label: 'HDD Level 2',
    },
    {
      value: '3',
      label: 'HDD Level 3',
    },
  ];

  const Datagiamgia = [
    {
      value: '10%',
      label: '10%',
    },
    {
      value: '75%',
      label: '75%',
    },
    {
      value: '100%',
      label: '100%',
    },

  ]
  const navigate=useNavigate();
  const [value, setValue] = useState('')
  const toolbarOptions = [
    ['bold', 'italic', 'underline', 'strike'],        // toggled buttons
    ['blockquote', 'code-block'],
    ['link', 'image', 'video', 'formula'],

    [{ 'header': 1 }, { 'header': 2 }],               // custom button values
    [{ 'list': 'ordered' }, { 'list': 'bullet' }, { 'list': 'check' }],
    [{ 'script': 'sub' }, { 'script': 'super' }],      // superscript/subscript
    [{ 'indent': '-1' }, { 'indent': '+1' }],          // outdent/indent
    [{ 'direction': 'rtl' }],                         // text direction

    [{ 'size': ['small', false, 'large', 'huge'] }],  // custom dropdown
    [{ 'header': [1, 2, 3, 4, 5, 6, false] }],

    [{ 'color': [] }, { 'background': [] }],          // dropdown with defaults from theme
    [{ 'font': [] }],
    [{ 'align': [] }],

    ['clean']
  ];
 

 // Initial values của form
const [initialValues,setInitialValues]=useState({});
useEffect(() => {
  if (productDetail) {
    setInitialValues({
      category: productDetail.category_id || '',
      price: productDetail.product_price || '',
      discount: productDetail.product_discount || 0,
      product_name: productDetail.product_name || '',
      hot: productDetail.product_hot || 0,
      quantity: productDetail.product_quantity || 0,
      infor_screen: productDetail.infor_screen || '',
      infor_system: productDetail.infor_system || '',
      infor_cpu: productDetail.infor_cpu || '',
      infor_ram: productDetail.infor_ram || '',
      moTa: productDetail.infor_more || '',
    });
  }
}, [productDetail]);
const validationSchema = Yup.object({
  // category: Yup.string().required('Danh mục sản phẩm là bắt buộc'),
  // price: Yup.number().required('Giá sản phẩm là bắt buộc').positive('Giá phải là số dương'),
  // Thêm các validation cho các trường khác nếu cần
});

  return (
    <div className='flex-1 bg-[#f2edf3]  grid xl:grid-cols-2 gap-3 auto-rows-[minmax(50px,_auto)] p-[24px]'>
      <div className='bg-white shadow-lg rounded-xl row-span-2 p-[12px] gap-3 flex flex-col '>
        <span className='text-[20px] font-semibold'>Sửa Sản Phẩm {id} </span>
        <Formik
        enableReinitialize
  initialValues={initialValues}
  validationSchema={validationSchema}
  onSubmit={(values) => {
  

const dataInforProduct={
  infor_screen:values.infor_screen,
  infor_system:values.infor_system,
  infor_cpu:values.infor_cpu,
  infor_ram:values.infor_ram,
  infor_more:values.moTa,

  product_name:values.product_name,
  product_price:values.price,
  product_hot:values.hot,
  product_quantity:values.quantity,
  product_discount:values.discount,
  category_id:values.category,
  product_id:numericId
 
  
  
}
dispatch(putInforProductAdminThunk(dataInforProduct))
navigate("/admin/quản-lí-sản-phẩm")
toast.success("Sửa sản phẩm thành công")



console.log(dataInforProduct);




}}
>
  {({ setFieldValue, values }) => (
    <Form className="flex flex-col gap-4">
      {/* Chọn loại sản phẩm */}
      <div className="flex gap-[1%]">
        <div className="flex w-[33%] h-auto flex-col gap-4">
          <label htmlFor="category" className="text-[14px] font-medium text-[#4A4A4A] tracking-wide">Loại sản phẩm</label>
          <Select
            value={values.category}  // bind value to Formik state
            onChange={(value,category_dad) => 
              
            {
              setFieldValue('category', value);
              handleCategoryChange(category_dad.category_dad)
            }  
            
            } // update Formik state when changed
            options={formattedCategories}
            className="h-[48px] bg-[#81818113] focus:text-[white] focus:bg-[#81818149] transition-all ease-in-out duration-500 rounded-lg text-[13px] outline-none"
          />
        </div>
        {/* Nhập giá sản phẩm */}
        <div className="flex w-[33%] h-auto flex-col gap-4">
          <label htmlFor="price" className="text-[14px] font-medium text-[#4A4A4A] tracking-wide">Giá sản phẩm</label>
          <Field
            type="number"
            name="price"
            className="h-[48px] bg-[#f7f7f7] focus:bg-white focus:shadow-md border border-[#ddd] rounded-lg text-[14px] p-3 outline-none transition duration-300 ease-in-out transform focus:scale-105 focus:border-[#4A90E2]"
            placeholder="Nhập giá sản phẩm"
          />
          <ErrorMessage name="price" component="div" className="text-[1.5rem] text-red-500" />
        </div>
        {/* Chọn mức giảm giá */}
        <div className="flex w-[33%] h-auto flex-col gap-4">
          <label htmlFor="discount" className="text-[13px] text-[#81818177] font-medium">Giảm giá</label>
          <Select
            value={values.discount}  // bind value to Formik state
            onChange={(value) => setFieldValue('discount', value)}  // update Formik state when changed
            options={Datagiamgia}
            className="h-[48px] bg-[#81818113] focus:text-[white] focus:bg-[#81818149] transition-all ease-in-out duration-500 rounded-lg text-[13px] outline-none"
          />
        </div>
      </div>
       <div className="flex w-[100%] h-auto flex-col gap-4">
          <label htmlFor="price" className="text-[14px] font-medium text-[#4A4A4A] tracking-wide">Tên sản phẩm</label>
          <Field
            type="text"
            name="product_name"
            className="h-[48px] bg-[#f7f7f7] focus:bg-white focus:shadow-md border border-[#ddd] rounded-lg text-[14px] p-3 outline-none transition duration-300 ease-in-out transform focus:scale-105 focus:border-[#4A90E2]"
            placeholder="Nhập tên sản phẩm"
          />
          <ErrorMessage name="product_name" component="div" className="text-[1.5rem] text-red-500" />
        </div>
        <div className='flex'>
        <div className="flex w-[49%] h-auto flex-col gap-4">
          <label htmlFor="hot" className="text-[14px] font-medium text-[#4A4A4A] tracking-wide">Hot</label>
          <Field
            type="text"
            name="hot"
            className="h-[48px] bg-[#f7f7f7] focus:bg-white focus:shadow-md border border-[#ddd] rounded-lg text-[14px] p-3 outline-none transition duration-300 ease-in-out transform focus:scale-105 focus:border-[#4A90E2]"
            placeholder="Nhập tên sản phẩm"
          />
          <ErrorMessage name="hot" component="div" className="text-[1.5rem] text-red-500" />
        </div>
        <div className="flex w-[49%] h-auto flex-col gap-4">
          <label htmlFor="price" className="text-[14px] font-medium text-[#4A4A4A] tracking-wide">Số lượng</label>
          <Field
            type="text"
            name="quantity"
            className="h-[48px] bg-[#f7f7f7] focus:bg-white focus:shadow-md border border-[#ddd] rounded-lg text-[14px] p-3 outline-none transition duration-300 ease-in-out transform focus:scale-105 focus:border-[#4A90E2]"
            placeholder="Nhập tên sản phẩm"
          />
          <ErrorMessage name="quantity" component="div" className="text-[1.5rem] text-red-500" />
        </div>
        </div>

        {(selectedCategory == '1' || selectedCategory == '2') && (
          <div className="bg-white shadow-lg rounded-xl row-span-2 p-[12px] gap-3 flex flex-col">
            <span className="text-[20px] font-semibold">Tạo thuộc tính</span>
            <div className="grid grid-cols-3 gap-4">
              <div className="flex h-auto flex-col gap-4">
              <label htmlFor="infor_screen" className="text-[13px] font-medium">Màn hình</label>
                      <Field
                        type="number"
                        name="infor_screen"
                        placeholder="Kích thước màn hình"
                        className="h-[48px] bg-[#f7f7f7] focus:bg-white focus:shadow-md border border-[#ddd] rounded-lg text-[14px] p-3 outline-none transition duration-300 ease-in-out transform focus:scale-105 focus:border-[#4A90E2]"
                        />
              </div>
             
              <div className="flex h-auto flex-col gap-4">
              <label htmlFor="infor_cpu" className="text-[13px] font-medium">Cpu</label>
                      <Field
                        type="number"
                        name="infor_cpu"
                        placeholder="Kích thước màn hình"
                        className="h-[48px] bg-[#f7f7f7] focus:bg-white focus:shadow-md border border-[#ddd] rounded-lg text-[14px] p-3 outline-none transition duration-300 ease-in-out transform focus:scale-105 focus:border-[#4A90E2]"
                        />
              </div>
              <div className="flex h-auto flex-col gap-4">
              <label htmlFor="infor_ram" className="text-[13px] font-medium">Ram</label>
                      <Field
                        type="number"
                        name="infor_ram"
                        placeholder="Kích thước màn hình"
                        className="h-[48px] bg-[#f7f7f7] focus:bg-white focus:shadow-md border border-[#ddd] rounded-lg text-[14px] p-3 outline-none transition duration-300 ease-in-out transform focus:scale-105 focus:border-[#4A90E2]"
                        />
              </div>
            
              <div className="flex h-auto flex-col gap-4">
                <label htmlFor="os" className="text-[13px] text-[#81818177] font-medium">Hệ điều hành</label>
                <Select
                 value={values.infor_system}  // bind value to Formik state
                 onChange={(value,category_dad) => 
                   
                 {
                   setFieldValue('infor_system', value);
               
                 }  
                }
                  placeholder="Vui lòng chọn hệ điều hành"
                
                  options={Datahe}
                  className="h-[48px] bg-[#81818113] focus:text-[white] focus:bg-[#81818149] transition-all ease-in-out duration-500 rounded-lg text-[13px] outline-none"
                />
              </div>
              
            </div>
          </div>
        )}

{/* <ModalAdminProduct/> */}
<div>
{/* {listProductColor?.map((item) => (
              <div
                  key={item.color}
              
                  className={`relative flex w-[25%] items-center gap-3 border py-4 px-6 rounded-md cursor-pointer hover:shadow-md }`}
              >
                <div className='absolute right-0 top-0 text-[1.5rem]'>
                  <IoMdClose />
                </div>
                  <img 
                      src='https://zshop.vn/images/detailed/129/iphone-15-pro-finish__5__cjwb-3i.jpg'
                      alt={item.color} 
                      className="w-20 rounded-md"
                  />
                  <div>
                      <h4 className="font-semibold text-[1.5rem]">Màu sắc: {item.color}</h4>
                      <p className="text-red-500 font-semibold text-[1.2rem]">Dung lượng: {item.productStorage.map((item)=>{
                        return item.storage
                      })}</p>
                  </div>
              </div>
          ))} */}
</div>
        <div className="bg-white shadow-lg rounded-xl p-[12px] gap-3 flex flex-col">
          <div className="col-span-3 flex h-[400px] overflow-y-hidden flex-col gap-4">
            <label htmlFor="moTa" className="text-[13px] text-[#81818177] font-medium">Mô tả</label>
            <ReactQuill
              theme="snow"
              value={values.moTa}
            onChange={(value) => setFieldValue('moTa', value)}  // update Formik state when changed
              modules={{
                toolbar: toolbarOptions,
              }}
              className="h-[100%] bg-[#81818113] focus:bg-[#81818149] transition-all ease-in-out duration-500 rounded-lg text-sm p-2"
            />
          </div>
        </div>

      {/* Submit Button */}
        <button type="submit" className="text-center bg-[#1A73E8] text-white text-[1.5rem] py-2 px-6 rounded-lg">
          Thêm sản phẩm
        </button>
      
    </Form>
  )}
</Formik>
      


    </div >
    </div>
  );
}

export default AdminEditProduct;

