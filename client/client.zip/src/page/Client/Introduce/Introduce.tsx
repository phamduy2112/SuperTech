import React from 'react'

function Introduce() {
  return (
    <div>Giới thiệu</div>
  )
}

export default Introduce