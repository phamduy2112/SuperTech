import React from 'react'

function CustomerCare() {
  return (
    <div>CustomerCare</div>
  )
}

export default CustomerCare