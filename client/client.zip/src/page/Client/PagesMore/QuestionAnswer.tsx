import React from 'react'

function QuestionAnswer() {
  return (
    <div>QuestionAnswer</div>
  )
}

export default QuestionAnswer