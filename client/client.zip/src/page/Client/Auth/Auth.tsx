
import { Outlet } from 'react-router-dom'




function AuthTemplate() {


  return (
    <div className=''>
     
      <Outlet />
   
    </div>
  )
}

export default AuthTemplate
