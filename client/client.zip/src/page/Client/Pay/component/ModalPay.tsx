import React, { useEffect, useState } from 'react';
import { Button, Modal } from 'antd';
import { getAutoBank, getOrderAll } from '../../../../service/order/order.service';

function ModalPay(props: any) {
  const [data, setData] = useState<any>(null);
  const [orderStatus, setOrderStatus] = useState<string>('');
  const [intervalId, setIntervalId] = useState<NodeJS.Timeout | null>(null);

  useEffect(() => {
    // Define an async function inside the useEffect
    const fetchApi = async () => {
      try {
        const response = await getAutoBank();
        if (response?.data?.content) {
          setData(response.data.content);
        } else {
          console.error("No content found in response.");
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchApi();  // Call the async function

    // Set up polling to check order status
    const id = setInterval(async () => {  // Make sure the function passed to setInterval is async
      try {
        const statusResponse = await getOrderAll(props?.data?.order_id);
        console.log('Status Response:', statusResponse); // Log the response for debugging
        if (statusResponse?.data?.order_pay === 1) {
          setOrderStatus('done');
          clearInterval(id);  // Stop polling when the desired status is received
          props.handleCancel();  // Assuming handleCancel is the method to close the modal
          window.location.href = '/';  // Redirect user to the home page
        }
      } catch (error) {
        console.error("Error polling order status:", error);
      }
    }, 15000);  // Polling every 15 seconds

    setIntervalId(id);  // Save the interval ID using the setter function from useState

    return () => {
      if (intervalId) clearInterval(intervalId);  // Clear the interval on component unmount
    };
  }, [props?.data?.order_id, props.handleCancel]);

  const totalOrder = props?.data?.order_total;
  const textOrder = 'supertech' + props?.data?.order_id;
  const isDataReady = Array.isArray(data) && data.length > 0;

  return (
    <>
      <Modal title={props.order_total} open={props.isModalOpen} onOk={props.handleOk} onCancel={props.handleCancel}>
        <div>
          {isDataReady ? (
            <div>
              <img
                src={`https://img.vietqr.io/image/${data[0]?.short_name}-${data[0]?.accountNumber}-compact.jpg?amount=${totalOrder}&addInfo=${textOrder}&accountName=${data[0]?.accountName}`}
                alt="QR Code"
              />
              {props.order_total}
              {orderStatus === 'done' && <p>Payment Received!</p>}
            </div>
          ) : (
            <p>Loading...</p>
          )}
        </div>
      </Modal>
    </>
  );
}

export default ModalPay;