export const DataSlideShow = [
    {
        id: 1,
        image: 'public/img/1.jpg',
        author: 'SUPERTECH',
        title: 'IPHONE 16',
        category: 'ĐIỆN THOẠI',
        info: 'iPhone 16 là phiên bản mới nhất trong dòng sản phẩm iPhone, nổi bật với thiết kế tinh tế và màn hình Super Retina XDR. Nó trang bị chip A17 Bionic mạnh mẽ, mang đến hiệu suất nhanh hơn và tiết kiệm năng lượng hơn. Camera cải tiến giúp chụp ảnh và quay video chất lượng cao, cùng với các tính năng AI thông minh, tạo ra trải nghiệm người dùng xuất sắc.'
    },
    {
        id: 2,
        image: 'public/img/2.jpg',
        author: 'SUPERTECH',
        title: 'IPHONE 16',
        category: 'ĐIỆN THOẠI',
        info: 'iPhone 16 là phiên bản mới nhất trong dòng sản phẩm iPhone, nổi bật với thiết kế tinh tế và màn hình Super Retina XDR. Nó trang bị chip A17 Bionic mạnh mẽ, mang đến hiệu suất nhanh hơn và tiết kiệm năng lượng hơn. Camera cải tiến giúp chụp ảnh và quay video chất lượng cao, cùng với các tính năng AI thông minh, tạo ra trải nghiệm người dùng xuất sắc.'
    },
    {
        id: 3,
        image: 'public/img/3.jpg',
        author: 'SUPERTECH',
        title: 'IPHONE 16',
        category: 'ĐIỆN THOẠI',
        info: 'iPhone 16 là phiên bản mới nhất trong dòng sản phẩm iPhone, nổi bật với thiết kế tinh tế và màn hình Super Retina XDR. Nó trang bị chip A17 Bionic mạnh mẽ, mang đến hiệu suất nhanh hơn và tiết kiệm năng lượng hơn. Camera cải tiến giúp chụp ảnh và quay video chất lượng cao, cùng với các tính năng AI thông minh, tạo ra trải nghiệm người dùng xuất sắc.'
    },
    {
        id: 4,
        image: 'public/img/4.jpg',
        author: 'SUPERTECH',
        title: 'IPHONE 16',
        category: 'ĐIỆN THOẠI',
        info: 'iPhone 16 là phiên bản mới nhất trong dòng sản phẩm iPhone, nổi bật với thiết kế tinh tế và màn hình Super Retina XDR. Nó trang bị chip A17 Bionic mạnh mẽ, mang đến hiệu suất nhanh hơn và tiết kiệm năng lượng hơn. Camera cải tiến giúp chụp ảnh và quay video chất lượng cao, cùng với các tính năng AI thông minh, tạo ra trải nghiệm người dùng xuất sắc.'
    },
    {
        id: 5,
        image: 'public/img/5.jpg',
        author: 'SUPERTECH',
        title: 'IPHONE 16',
        category: 'ĐIỆN THOẠI',
        info: 'iPhone 16 là phiên bản mới nhất trong dòng sản phẩm iPhone, nổi bật với thiết kế tinh tế và màn hình Super Retina XDR. Nó trang bị chip A17 Bionic mạnh mẽ, mang đến hiệu suất nhanh hơn và tiết kiệm năng lượng hơn. Camera cải tiến giúp chụp ảnh và quay video chất lượng cao, cùng với các tính năng AI thông minh, tạo ra trải nghiệm người dùng xuất sắc.'
    }
]